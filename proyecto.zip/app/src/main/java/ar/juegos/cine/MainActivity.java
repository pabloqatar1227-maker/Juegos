package ar.juegos.cine;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView wv;
    private SpeechRecognizer sr;
    private String pendingLang = null;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> r.grant(r.getResources()));
            }
        });
        wv.addJavascriptInterface(new Bridge(), "AndroidVoz");
        wv.loadUrl("file:///android_asset/index.html");
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] g) {
        if (pendingLang != null) {
            String l = pendingLang; pendingLang = null;
            if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startRec(l); else cb("", "[]", "not-allowed");
        }
    }

    // El botón "atrás" (o el círculo/B del joystick): vuelve al menú del juego; en el menú, cierra la app.
    @Override public void onBackPressed() {
        wv.evaluateJavascript("(function(){return !!document.getElementById('ishome')})()", v -> {
            if ("true".equals(v)) finish();
            else wv.evaluateJavascript("goHome()", null);
        });
    }

    @Override protected void onDestroy() {
        if (sr != null) { sr.destroy(); sr = null; }
        wv.destroy();
        super.onDestroy();
    }

    private void cb(String text, String alts, String err) {
        final String js = "window.__vozCb&&window.__vozCb(" + JSONObject.quote(text) + "," + JSONObject.quote(alts) + "," + JSONObject.quote(err) + ")";
        runOnUiThread(() -> wv.evaluateJavascript(js, null));
    }

    private void startRec(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { cb("", "[]", "service-not-allowed"); return; }
        if (sr != null) { sr.destroy(); }
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle p) {}
            public void onEvent(int t, Bundle p) {}
            public void onError(int e) {
                String m = e == SpeechRecognizer.ERROR_NO_MATCH ? "no-match"
                        : e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "speech-timeout"
                        : e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ? "not-allowed"
                        : e == 11 ? "service-not-allowed" : "error-" + e;
                cb("", "[]", m);
            }
            public void onResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l == null || l.isEmpty()) { cb("", "[]", "no-match"); return; }
                cb(l.get(0), new JSONArray(l).toString(), "");
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4);
        sr.startListening(i);
    }

    private class Bridge {
        @JavascriptInterface public void start(final String lang) { runOnUiThread(() -> startRec(lang)); }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> { if (sr != null) { sr.cancel(); } cb("", "[]", "cancel"); });
        }
    }
}
